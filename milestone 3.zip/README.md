ENSF 409 Final Project

Zelong Zhang (30060130) zelong.zhang1@ucalgary.ca
Maaz Khurram (30051845) maaz.khurram@ucalgary.ca
Saksham Nanda (30045696) saksham.nanda@ucalgary.ca

This application consists of two separate Java projects. One is the RegistrationServer project and the other is the RegistrationClient project. 
There are two zipped folders which are the two projects exported from Eclipse. 
To run the projects, import the two projects into Eclipse IDE.
Then run the server project as a java application with RegistrationServer as the main class.
After that, run the client project as a java application with RegistrationClient as the main class.
To test the client, use username:Thomas Theo and password:thomas1234
*In order for the two projects to work, the database must be online. 
*As the MySQL database is not hosted publically, please contact one of us by email if you wish to set up a time to test the code.

BONUS:

1.Deploy the project; run the server and client on separate machines (5 marks)
3.Maintain a list of users and develop login/out feature (5 marks)